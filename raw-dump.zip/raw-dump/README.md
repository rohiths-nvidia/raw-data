# Raw-data dump: GPU sandbox ecosystem map

> **NVIDIA confidential.** Built from an NVIDIA-internal tracker, internal meeting notes and public web research. Don't share outside NVIDIA.

Everything needed to rebuild or rethink the [GPU sandbox ecosystem map](../../../GPU%20sandbox%20ecosystem%20map.html) without this session: the source spreadsheet, every research agent's raw output, every checker verdict, the merged graph and the whiteboard. Built Tue Nov 3, 2026.

## Start here

Load **`sandbox-ecosystem-raw-dump.json`**. It holds everything below in one file:

| Key | What it is |
|---|---|
| `assignment` | The ask: Vikranth's Nov 3 method (sandbox, framework, infrastructure, customers; top ~20; rank by harnesses and customers, not revenue; post-training under Sandbox), the output he asked for, and the GPU angle |
| `schema` | The five layers, the seven relations, node and edge fields, and the confidence rules |
| `tracker.tabs` | All 12 tabs of `vera_agentic_software_strategy.xlsx` (Tom Matthias's Vera tracker), row by row, with hyperlinks |
| `research` | Per research group: `entities`, `edges`, `gaps`, and `checker.verdicts` (by edge index) plus `checker.missed` |
| `merged` | The cleaned graph the page draws: `nodes`, `edges`, and `meta` (provenance, caveats, and `story`: Madison's question, her two prongs, the gold-standard recipe with sources) |

## The question the graph has to answer

Madison Huang, Oct 29 Agent Ecosystem Weekly, for "ensure agents call CUDA-X accelerated tools": **who should be making GPU sandboxes, who already is, and how do we intercept them?** Her two prongs:

1. **Make harnesses GPU-aware.** First target is Hermes on RTX Spark (a hardware checker that finds the GPU), then benchmarks with and without GPU apps, then more harnesses and devices.
2. **Establish gold-standard GPU sandboxes.** Map the sandbox ecosystem including post-training partners spinning up RL sandboxes (Vikranth, Rohith); model the gold standard, likely Kernel Factory on Modal, and build a recipe for the others.

The bar for a GPU sandbox is **device pass-through** (Tom Matthias, Nov 2): Firecracker lacks it, Cloud Hypervisor has it.

## Files

| Path | Contents |
|---|---|
| `sandbox-ecosystem-raw-dump.json` | Everything, one file (about 1.7 MB), including `gpu_research` |
| `tracker-tabs/*.tsv` | The 12 tabs as TSV (first column is the sheet row), plus `*.links.tsv` for each tab's hyperlinks |
| `research/<group>.json` | Raw output per group: `tier1-sandboxes`, `longtail-sandboxes`, `browser-sandboxes`, `harnesses-coding`, `harnesses-general`, `post-training-rl` (public web, each checked), `kb-notes` (meeting notes, not web-checked) |
| `research/workflow-journal.jsonl` | The mapping workflow's journal: one `{"type":"result"}` line per agent |
| `research/gpu-status.json`, `research/gpu-workflow-journal.jsonl` | The Nov 3 GPU-status check: one answer per sandbox (status, offer, URL, checker verdict) and that workflow's journal |
| `merged/nodes.csv`, `merged/edges.csv` | The merged graph as tables (see the column list in [../README.md](../README.md)) |
| `merged/graph.json` | The merged graph as the page loads it |
| `merged/rejected-edges.csv` | Links the checker refuted (none this run) |
| `merged/merge-log.txt` | Every name conflict, direction fix, dropped link and node created only by a link, from the last merge |
| `whiteboard-2026-11-03.jpg` | Vikranth's whiteboard: Harness, Sandbox (hosted | post-training box), Framework, Infra |

## Numbers in this build

- **Tracker:** 71 providers in `partner_virtualization_tooling` (14 "Active" with Vera, 57 "Not confirmed"), each with its framework and GPU pass-through status.
- **Research:** 737 raw links from 7 agents, plus 58 the checkers added. Checkers confirmed 546 web links, rated 107 weak and refuted none. The notes agent returned 84 links, which no web checker reviewed.
- **Merged:** 420 nodes (210 customers, 85 harnesses, 86 sandboxes, 20 frameworks, 19 infrastructure; six duplicate sandbox names merged) and 738 links, of which medium and high confidence are the "reliable" set the pages draw and count.
- **GPU status:** the tracker covers 11 of the 81 sandboxes that aren't NVIDIA's own. A second pass on Nov 3 checked the other 70 against provider docs and pricing, and a checker opened every page (60 confirmed, 10 weak). After the Nov 3 review, 5 of the 81 are inactive and not counted: Scrapybara, Agentuity and run.cloud shut down or closed their sandboxes, and Tinker and Fireworks AI run no hosted sandbox (their rollouts run elsewhere). The other 76 split into 9 that give the agent a full GPU (device pass-through or a dedicated GPU VM; 6 of them with a caveat), 15 with a partial GPU (gVisor or containers), 2 with a browser rendering GPU only (Browserless, Kernel), 48 with no GPU and 2 not known (Inherent, Unsloth). The pages and `sandboxes/GPU status.md` use these counts. Each answer is in `research/gpu-status.json` with its URL, and the node carries `gpu_status`, `gpu_short`, `gpu_url`, `gpu_source`, `gpu_conf`.

## How the merge treated the raw data (so you can redo it differently)

- Names are canonicalized by role: "Vercel" as a customer is Vercel the company, as a sandbox Vercel Sandbox, as a harness v0. The same goes for Mistral, Hugging Face, Docker, Cloudflare and Morph.
- A "customer_of" link into a post-training provider becomes `trains_with` only when its evidence is about training or RL. Modal's sandbox customers stay `customer_of`.
- A `hosted_on` or `runs_on_framework` link whose target is really a sandbox becomes `uses_sandbox`, for example Steel.dev on Fly Machines.
- Three links were dropped: Kernel → Vercel (dashboard DNS only), Anyscale → Nscale (forward-looking), and Modal as a customer of Devin (a corporate purchase, not part of Modal's stack).
- GPU status comes from the Vera tracker (checked Nov 2) where it has one; otherwise from the Nov 3 GPU check. The tracker always wins, and weak answers carry "(weak evidence)" in `gpu_short` and `gpu_conf: low`.
- Browser sandboxes with GPUs (Browserless, Kernel) use them for rendering, not for the agent's CUDA code; the pages leave them out of "GPU for code" counts.

## Known gaps

- **Harness-to-sandbox links are thin.** Few harnesses publish where their cloud agents run. Apoorv Chaudhary's harness conversations are the planned source.
- **Infrastructure and runtime are each unknown for about a third of sandboxes**; see the breakdowns on the map page.
- **Post-training providers rarely say what their RL rollouts run on.**
- **Meeting-note links are colleagues' views.** For example, Meta as a Daytona customer is David Messina's view, unconfirmed by Daytona.

## Rebuild

Run the scripts in `../scripts/`, each with arguments as given in its docstring: `dump_xlsx.py` (spreadsheet → TSV), `build_base.py` (tracker → base layer), `merge.py` (base + journal → graph), `publish.py` (graph → page + CSV), `dump.py` (this folder).
